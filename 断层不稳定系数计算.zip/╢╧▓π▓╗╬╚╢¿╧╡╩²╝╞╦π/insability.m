% 1. 输入参数：断层的走向、倾角，应力场的主应力轴走向、倾角
strike_f = 90; % 断层走向 (degrees, 正北为0°)
dip_f = 30;    % 断层倾角 (degrees)

% 主应力轴的走向和倾角
azimuth_1 = 0;   % 主应力轴1的走向 (degrees)
dip_1 = 45;      % 主应力轴1的倾角 (degrees)

azimuth_2 = 90;  % 主应力轴2的走向 (degrees)
dip_2 = 0;       % 主应力轴2的倾角 (degrees)

azimuth_3 = 180; % 主应力轴3的走向 (degrees)
dip_3 = 60;      % 主应力轴3的倾角 (degrees)

% 额外输入参数
friction_coefficient = 0.6; % 断层的摩擦系数
R = 0.8; % 应力场的 R 值（可以调整）

% 2. 计算应力张量中的方向余弦
% 将走向和倾角转换为单位向量 (方向余弦)
[ux1, uy1, uz1] = angles_to_unit_vector(azimuth_1, dip_1);
[ux2, uy2, uz2] = angles_to_unit_vector(azimuth_2, dip_2);
[ux3, uy3, uz3] = angles_to_unit_vector(azimuth_3, dip_3);

% 断层的单位向量
[ufx, ufy, ufz] = angles_to_unit_vector(strike_f, dip_f);

% 3. 计算剪切应力和法向应力
% 应力张量的计算，基于方向余弦的组合
sigma_n = [ux1 ux2 ux3]; % 应力张量的法向部分
sigma_s = [ufx ufy ufz]; % 断层面方向的剪切应力

% 4. 断层不稳定系数的计算
% 计算剪切应力
tau = calculate_shear_stress(sigma_n, sigma_s);

% 计算法向应力
sigma_n = calculate_normal_stress(sigma_n, sigma_s);

% 使用摩擦系数和 R 值计算不稳定系数
% 结合应力场参数 R 的影响，调整剪切应力和法向应力的计算
failure_coefficient = min((tau * R) / (sigma_n * friction_coefficient), 1);

% 显示结果
disp(['断层不稳定系数: ', num2str(failure_coefficient)]);