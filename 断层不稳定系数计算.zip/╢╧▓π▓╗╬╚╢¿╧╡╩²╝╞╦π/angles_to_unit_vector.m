function [ux, uy, uz] = angles_to_unit_vector(azimuth, dip)
    % 将角度转换为单位向量
    % azimuth: 走向角 (degrees)
    % dip: 倾角 (degrees)
    azimuth = deg2rad(azimuth); % 转为弧度
    dip = deg2rad(dip);         % 转为弧度

    % 计算单位向量
    ux = cos(dip) * sin(azimuth);
    uy = cos(dip) * cos(azimuth);
    uz = sin(dip);
end