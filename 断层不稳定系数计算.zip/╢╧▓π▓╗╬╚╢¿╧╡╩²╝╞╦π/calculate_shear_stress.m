function tau = calculate_shear_stress(sigma_n, sigma_s)
    tau = dot(sigma_n, sigma_s); % 计算剪切应力
end