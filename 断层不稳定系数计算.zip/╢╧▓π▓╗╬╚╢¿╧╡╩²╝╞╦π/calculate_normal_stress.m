function sigma_n = calculate_normal_stress(sigma_n, sigma_s)
    sigma_n = dot(sigma_n, sigma_s); % 计算法向应力
end